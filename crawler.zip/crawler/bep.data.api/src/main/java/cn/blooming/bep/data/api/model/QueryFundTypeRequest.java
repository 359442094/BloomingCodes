package cn.blooming.bep.data.api.model;

import cn.blooming.bep.common.api.model.BaseRequest;

public class QueryFundTypeRequest extends BaseRequest {

    private static final long serialVersionUID = 110215905509717588L;

}
