package cn.blooming.bep.data.api.model;

import cn.blooming.bep.common.api.model.BaseRequest;

public class QueryBankListRequest extends BaseRequest {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8167886572513256114L;


	
}
