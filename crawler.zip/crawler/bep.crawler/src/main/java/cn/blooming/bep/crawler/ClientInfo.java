package cn.blooming.bep.crawler;
/**
 * Client配置信息
 * */
public class ClientInfo {
    /**
     * 行业客户编号clientId
     * */
    public static final String CLIENT_ID="zawy";

    /**
     * 行业客户的操作员id staffUsername
     * */
    public static final String STAFF_USERNAME="API_USER";

    /**
     * 接口版本 version
     * */
    public static final String VERSION="1.0";

}
