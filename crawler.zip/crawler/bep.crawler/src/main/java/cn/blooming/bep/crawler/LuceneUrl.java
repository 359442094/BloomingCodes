package cn.blooming.bep.crawler;

public class LuceneUrl {
    /**
     * 全部索引保存/读取路径
     * */
    public static final String LUCENE_DEFAULT_PATH="D:\\lucene\\defaultIndex";


    /**
     * 关键词保存/读取路径
     * */
    //public static final String LUCENE_KEYTERM_PATH="D:\\lucene\\keytermIndex";

}
