package cn.blooming.bep.crawler.model.service.fund;

/**
 * 更新同类均值
 * */
public interface FundStatsticsHandlerService {
    //开始更新
    String start() throws Exception;
}
