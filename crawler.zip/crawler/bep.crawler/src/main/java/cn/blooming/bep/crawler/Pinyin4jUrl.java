package cn.blooming.bep.crawler;
/**
 * 多音字配置相关路径
 * */
public class Pinyin4jUrl {
    /**
     * 项目中多音字文件的路径
     * */
    public static final String POLYPHONE_PATH="pinyin4j/polyphone.txt";
}
