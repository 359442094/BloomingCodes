package cn.blooming.bep.crawler.model.service.fund;

public interface DeleteRedundantDataService {
    void delete();
}
